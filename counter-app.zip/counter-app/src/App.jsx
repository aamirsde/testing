import "./App.css";
import Counter from "./components/Counter";
import FormHolder from "./components/FormHolder";

function App() {
  return (
    <div>
      <Counter />
      <br />
      <br />
      <br />
      <FormHolder />
    </div>
  );
}

export default App;
