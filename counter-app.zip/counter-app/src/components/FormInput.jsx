import React from "react";
import "./Form.css";

const FormInput = (props) => {
  return (
    <div className="form-input">
      <input type="text" onChange={(e) => props.setName(e.target.value)} />
    </div>
  );
};

export default FormInput;
