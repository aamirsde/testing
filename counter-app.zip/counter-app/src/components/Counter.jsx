import React, { useState } from "react";
import "./Counter.css";

const Counter = () => {
  const [count, setCount] = useState(0);

  const onButtonClick = () => {
    setCount((prev) => prev + 1);
  };

  return (
    <div className="counter-container">
      <p>U have Clicked {count} times</p>
      <button onClick={onButtonClick}>Click Me</button>
    </div>
  );
};

export default Counter;
