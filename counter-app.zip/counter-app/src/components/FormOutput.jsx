import React from "react";

const FormOutput = (props) => {
  return (
    <div>
      <p>Your Input : {props.name}</p>
    </div>
  );
};

export default FormOutput;
