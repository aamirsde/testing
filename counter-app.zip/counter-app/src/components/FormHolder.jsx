import React, { useState } from "react";
import FormInput from "./FormInput";
import FormOutput from "./FormOutput";

const FormHolder = () => {
  const [name, setName] = useState("");

  return (
    <div>
      <FormInput name={name} setName={setName} />
      <FormOutput name={name} />
    </div>
  );
};

export default FormHolder;
